package com.sarthika.PlacementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
